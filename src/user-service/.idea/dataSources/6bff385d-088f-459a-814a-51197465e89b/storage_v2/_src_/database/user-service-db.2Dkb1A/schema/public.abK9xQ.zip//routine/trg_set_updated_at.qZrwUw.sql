create function trg_set_updated_at() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.updated_at = now();
RETURN NEW;
END;
$$;

alter function trg_set_updated_at() owner to postgres;

